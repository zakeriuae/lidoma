/**
 * اسکریپت اصلی سایت لیدوما
 */

// راه‌اندازی آیکون‌های Lucide
document.addEventListener('DOMContentLoaded', () => {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // راه‌اندازی مودال‌های پیش‌فرض
    initDefaultModals();
    
    // راه‌اندازی سایر قابلیت‌ها
    initAnimations();
    initConsultants();
    initLeads();
    initFloatingNumbers();
});

/**
 * راه‌اندازی مودال‌های پیش‌فرض
 */
function initDefaultModals() {
    // مودال درخواست دمو
    modalManager.create('demo-request', 'درخواست دمو', `
        <form id="demo-form" class="space-y-6">
            <div>
                <label class="block text-sm font-bold text-slate-300 mb-2">نام و نام خانوادگی</label>
                <input type="text" required 
                    class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
                    placeholder="نام خود را وارد کنید">
            </div>
            <div>
                <label class="block text-sm font-bold text-slate-300 mb-2">شماره موبایل</label>
                <input type="tel" required 
                    class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
                    placeholder="09123456789">
            </div>
            <div>
                <label class="block text-sm font-bold text-slate-300 mb-2">نام کلینیک</label>
                <input type="text" required 
                    class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
                    placeholder="نام کلینیک خود را وارد کنید">
            </div>
            <div>
                <label class="block text-sm font-bold text-slate-300 mb-2">تخصص کلینیک</label>
                <select required 
                    class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20">
                    <option value="">انتخاب کنید</option>
                    <option value="زیبایی">زیبایی</option>
                    <option value="دندانپزشکی">دندانپزشکی</option>
                    <option value="کاشت مو">کاشت مو</option>
                    <option value="جراحی پلاستیک">جراحی پلاستیک</option>
                    <option value="سایر">سایر</option>
                </select>
            </div>
        </form>
    `, {
        footer: `
            <button onclick="modalManager.close('demo-request')" class="btn-secondary">انصراف</button>
            <button onclick="submitDemoForm()" class="btn-primary">ارسال درخواست</button>
        `
    });

    // مودال تماس با ما
    modalManager.create('contact', 'تماس با ما', `
        <div class="space-y-6">
            <div class="glass-panel p-4 rounded-xl border border-white/10">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-brand-500/20 p-2 rounded-lg text-brand-400">
                        <i data-lucide="phone" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <div class="text-xs text-slate-400">تلفن</div>
                        <div class="text-white font-bold" dir="ltr">02181640162</div>
                    </div>
                </div>
            </div>
            <div class="glass-panel p-4 rounded-xl border border-white/10">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-brand-500/20 p-2 rounded-lg text-brand-400">
                        <i data-lucide="phone" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <div class="text-xs text-slate-400">موبایل</div>
                        <div class="text-white font-bold" dir="ltr">09124452898</div>
                    </div>
                </div>
            </div>
            <div class="glass-panel p-4 rounded-xl border border-white/10">
                <div class="flex items-center gap-3 mb-3">
                    <div class="bg-brand-500/20 p-2 rounded-lg text-brand-400">
                        <i data-lucide="map-pin" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <div class="text-xs text-slate-400">آدرس</div>
                        <div class="text-white font-bold">کامرانیه شمالی، خیابان سعیدی (مهماندوست)، خیابان حسینی، خیابان فریبرز متقیان، کوچه امینی متقیان، پلاک ۴</div>
                    </div>
                </div>
            </div>
        </div>
    `);

    // مودال ویدیو معرفی
    modalManager.create('video', 'ویدیو معرفی لیدوما', `
        <div class="aspect-video bg-black/50 rounded-xl overflow-hidden">
            <iframe class="w-full h-full" 
                src="https://www.youtube.com/embed/YOUR_VIDEO_ID" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>
            </iframe>
        </div>
    `, {
        width: '900px'
    });

    // اضافه کردن event listener برای دکمه‌های باز کردن مودال
    document.addEventListener('click', (e) => {
        const demoBtn = e.target.closest('[data-modal="demo-request"]');
        const contactBtn = e.target.closest('[data-modal="contact"]');
        const videoBtn = e.target.closest('[data-modal="video"]');
        
        if (demoBtn) {
            e.preventDefault();
            modalManager.open('demo-request');
        }
        
        if (contactBtn) {
            e.preventDefault();
            modalManager.open('contact');
        }
        
        if (videoBtn) {
            e.preventDefault();
            modalManager.open('video');
        }
    });

    // به‌روزرسانی آیکون‌ها بعد از باز شدن مودال
    document.addEventListener('DOMContentLoaded', () => {
        const observer = new MutationObserver(() => {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}

/**
 * ارسال فرم دمو
 */
function submitDemoForm() {
    const form = document.getElementById('demo-form');
    if (!form || !form.checkValidity()) {
        form.reportValidity();
        return;
    }

    // اینجا می‌توانید درخواست را به سرور ارسال کنید
    alert('درخواست شما با موفقیت ثبت شد! به زودی با شما تماس خواهیم گرفت.');
    modalManager.close('demo-request');
    form.reset();
}

/**
 * راه‌اندازی انیمیشن‌ها
 */
function initAnimations() {
    // Counter Animation
    function animateValue(obj, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            obj.innerHTML = Math.floor(progress * (end - start) + start).toLocaleString() + ' <span class="text-xs text-slate-500 font-sans">تومان</span>';
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }

    // Observer for price counters
    const leadSection = document.getElementById('leads');
    if (leadSection) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const counters = document.querySelectorAll('.price-counter');
                    counters.forEach(counter => {
                        const target = parseInt(counter.getAttribute('data-target'));
                        if (target && !counter.classList.contains('animated')) {
                            animateValue(counter, 0, target, 2000);
                            counter.classList.add('animated');
                        }
                    });
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });

        observer.observe(leadSection);
    }
}

/**
 * راه‌اندازی بخش مشاوران
 */
function initConsultants() {
    const consultants = [
        { name: "سارا خدیوی", role: "مشاور دندانپزشکی", exp: "4 سال", rate: "32٪", img: "assets/images/Picture3.png", status: "آنلاین" },
        { name: "علی رضایی", role: "مشاور کاشت مو", exp: "6 سال", rate: "28٪", img: "assets/images/photo_2021-10-08_09-52-04.jpg", status: "در جلسه" },
        { name: "آرزو نامدار", role: "مشاور زیبایی", exp: "5 سال", rate: "35٪", img: "assets/images/Picture2.png", status: "آنلاین" },
        { name: "محمدرضا مظفری", role: "مشاور دندانپزشکی", exp: "3 سال", rate: "25٪", img: "assets/images/photo_2024-05-16_10-55-18.jpg", status: "آفلاین" },
    ];

    const container = document.getElementById('consultant-grid');
    if (!container) return;

    consultants.forEach(c => {
        const statusColor = c.status === "آنلاین" 
            ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" 
            : (c.status === "آفلاین" ? "bg-slate-500" : "bg-accent-500");
        
        container.innerHTML += `
            <div class="glass-card p-6 rounded-3xl group relative hover:bg-white/5 transition duration-500">
                <div class="absolute top-5 left-5 flex items-center gap-2 bg-black/40 px-3 py-1 rounded-full border border-white/10 backdrop-blur-md z-10">
                    <span class="w-2 h-2 rounded-full ${statusColor} animate-pulse"></span>
                    <span class="text-[11px] text-slate-300 font-medium">${c.status}</span>
                </div>
                
                <div class="flex flex-col items-center text-center mt-2">
                    <div class="relative mb-5 group-hover:scale-105 transition duration-500">
                        <div class="absolute -inset-1 bg-gradient-to-br from-brand-500 to-purple-600 rounded-full blur opacity-40 group-hover:opacity-70 transition"></div>
                        <img src="${c.img}" class="relative w-24 h-24 rounded-full border-2 border-white/10 object-cover" alt="${c.name}">
                    </div>
                    
                    <h4 class="text-white font-bold text-xl mb-1">${c.name}</h4>
                    <p class="text-brand-400 text-sm mb-6 font-medium">${c.role}</p>
                    
                    <div class="w-full bg-black/20 rounded-2xl p-4 flex justify-between items-center text-sm border border-white/5 mb-6">
                        <div class="text-slate-400">نرخ تبدیل</div>
                        <div class="text-white font-bold font-mono text-lg bg-white/5 px-2 py-1 rounded-lg">${c.rate}</div>
                    </div>
                    
                    <button class="w-full py-3 rounded-xl bg-white/5 hover:bg-brand-600 hover:text-white text-slate-300 text-sm font-bold transition border border-white/10 hover:border-brand-500 shadow-lg group-hover:shadow-glow-brand" data-modal="consultant-${c.name}">
                        مشاهده رزومه
                    </button>
                </div>
            </div>
        `;
    });

    // ایجاد مودال برای هر مشاور
    consultants.forEach(c => {
        modalManager.create(`consultant-${c.name}`, `رزومه ${c.name}`, `
            <div class="space-y-6">
                <div class="flex items-center gap-4">
                    <img src="${c.img}" class="w-20 h-20 rounded-full border-2 border-brand-500/30" alt="${c.name}">
                    <div>
                        <h3 class="text-2xl font-bold text-white">${c.name}</h3>
                        <p class="text-brand-400">${c.role}</p>
                        <p class="text-sm text-slate-400 mt-1">سابقه: ${c.exp}</p>
                    </div>
                </div>
                <div class="glass-panel p-4 rounded-xl">
                    <h4 class="text-white font-bold mb-3">نرخ تبدیل موفقیت</h4>
                    <div class="text-3xl font-bold text-brand-400">${c.rate}</div>
                </div>
                <div class="glass-panel p-4 rounded-xl">
                    <h4 class="text-white font-bold mb-3">درباره مشاور</h4>
                    <p class="text-slate-300 leading-relaxed">
                        ${c.name} با ${c.exp} سال سابقه در زمینه ${c.role}، یکی از برترین مشاوران فروش تلفنی است. 
                        با نرخ تبدیل ${c.rate}، آماده کمک به رشد کسب‌وکار شماست.
                    </p>
                </div>
                <button class="w-full btn-primary" onclick="modalManager.close('consultant-${c.name}'); modalManager.open('demo-request');">
                    استخدام مشاور
                </button>
            </div>
        `);
    });

    // Event listener برای دکمه‌های مشاهده رزومه
    document.addEventListener('click', (e) => {
        const btn = e.target.closest(`[data-modal^="consultant-"]`);
        if (btn) {
            e.preventDefault();
            const modalId = btn.getAttribute('data-modal');
            modalManager.open(modalId);
        }
    });

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

/**
 * راه‌اندازی بخش لیدها
 */
function initLeads() {
    const leads = [
        { 
            title: "کاشت مو", 
            loc: ["تهران", "اصفهان", "شیراز", "مشهد"], 
            price: 250000, 
            count: "50", 
            type: "ورودی گوگل", 
            svg: `<img src="assets/images/0111.png" alt="کاشت مو" class="w-full h-full object-contain">`, 
            badge: "VIP" 
        },
        { 
            title: "ایمپلنت", 
            loc: ["تهران", "مشهد", "تبریز", "کرج"], 
            price: 200000, 
            count: "20", 
            type: "اینستاگرام", 
            svg: `<img src="assets/images/0222.png" alt="ایمپلنت" class="w-full h-full object-contain">`, 
            badge: "جدید" 
        },
        { 
            title: "ابدومینوپلاستی", 
            loc: ["تهران", "کرج", "قم", "رشت"], 
            price: 280000, 
            count: "100", 
            type: "پیامکی", 
            svg: `<img src="assets/images/0333.png" alt="ابدومینوپلاستی" class="w-full h-full object-contain">`, 
            badge: "ارزان" 
        },
        { 
            title: "جراحی بینی", 
            loc: ["تهران", "کرمانشاه", "اهواز", "یزد"], 
            price: 300000, 
            count: "15", 
            type: "سایت", 
            svg: `<img src="assets/images/0444.png" alt="جراحی بینی" class="w-full h-full object-contain">`, 
            badge: "کمیاب" 
        },
    ];

    const container = document.getElementById('lead-grid');
    if (!container) return;

    leads.forEach(l => {
        const badgeColor = l.badge === "VIP" 
            ? "bg-accent-500 text-black shadow-[0_0_15px_rgba(245,158,11,0.5)]" 
            : "bg-white/10 text-white border border-white/10";
        
        container.innerHTML += `
            <div class="glass-card rounded-3xl overflow-hidden hover:-translate-y-2 transition duration-500 group border border-white/5 z-10 relative">
                <div class="h-40 relative overflow-hidden flex items-center justify-center bg-gradient-to-br from-white/5 to-white/0 group-hover:from-brand-900/20 group-hover:to-brand-800/20 transition duration-500">
                    <div class="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
                    <div class="w-28 h-28 text-brand-400/50 group-hover:text-brand-400 group-hover:scale-110 transition duration-500 relative z-10" style="filter: drop-shadow(0 0 20px rgba(245, 158, 11, 0.6)) drop-shadow(0 0 40px rgba(245, 158, 11, 0.3));">
                        ${l.svg}
                    </div>
                    <div class="absolute inset-0 bg-gradient-to-t from-[#0B0F19] to-transparent"></div>
                    <div class="absolute top-4 right-4 ${badgeColor} backdrop-blur-md px-3 py-1 rounded-lg text-xs font-bold shadow-lg z-20">
                        ${l.badge}
                    </div>
                    <div class="absolute bottom-4 right-4 text-white font-bold text-lg drop-shadow-md z-20">
                        ${l.title}
                    </div>
                </div>
                <div class="p-6 pt-2">
                    <div class="flex flex-wrap items-center gap-2 text-xs text-slate-400 mb-6">
                        ${Array.isArray(l.loc) ? l.loc.map(city => `<span class="bg-white/5 px-2 py-1 rounded border border-white/5">${city}</span>`).join('') : `<span class="bg-white/5 px-2 py-1 rounded border border-white/5">${l.loc}</span>`}
                    </div>
                    <div class="flex items-end justify-between border-t border-white/5 pt-4">
                        <div>
                            <div class="text-[10px] text-slate-500 mb-1">قیمت هر لید</div>
                            <div class="text-accent-400 font-bold font-mono text-xl price-counter" data-target="${l.price}">0 <span class="text-xs text-slate-500 font-sans">تومان</span></div>
                        </div>
                        <button class="w-10 h-10 rounded-xl bg-white text-black flex items-center justify-center hover:bg-brand-400 hover:text-white transition shadow-[0_0_15px_rgba(255,255,255,0.2)] hover:shadow-glow-brand" data-modal="lead-${l.title}">
                            <i data-lucide="plus" class="w-5 h-5"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    // ایجاد مودال برای هر لید
    leads.forEach(l => {
        modalManager.create(`lead-${l.title}`, `خرید لید ${l.title}`, `
            <div class="space-y-6">
                <div class="glass-panel p-6 rounded-xl">
                    <h3 class="text-xl font-bold text-white mb-4">${l.title}</h3>
                    <div class="mb-4">
                        <div>
                            <div class="text-xs text-slate-400 mb-2">موقعیت</div>
                            <div class="flex flex-wrap gap-2">
                                ${Array.isArray(l.loc) ? l.loc.map(city => `<span class="bg-white/5 px-3 py-1.5 rounded border border-white/10 text-white text-sm">${city}</span>`).join('') : `<span class="bg-white/5 px-3 py-1.5 rounded border border-white/10 text-white text-sm">${l.loc}</span>`}
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="text-xs text-slate-400 mb-1">تعداد لید موجود</div>
                        <div class="text-2xl font-bold text-brand-400">${l.count} لید</div>
                    </div>
                </div>
                <div class="glass-panel p-6 rounded-xl">
                    <div class="flex justify-between items-center mb-4">
                        <span class="text-slate-300">قیمت هر لید</span>
                        <span class="text-2xl font-bold text-accent-400">${l.price.toLocaleString()} تومان</span>
                    </div>
                    <div class="flex gap-2 items-center">
                        <label class="text-sm text-slate-300">تعداد:</label>
                        <input type="number" min="1" max="${l.count}" value="1" 
                            class="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white w-20 text-center focus:outline-none focus:border-brand-500">
                        <span class="text-sm text-slate-400">لید</span>
                    </div>
                    <div class="mt-4 pt-4 border-t border-white/10">
                        <div class="flex justify-between items-center">
                            <span class="text-slate-300 font-bold">جمع کل:</span>
                            <span class="text-2xl font-bold text-white" id="total-price-${l.title}">${l.price.toLocaleString()} تومان</span>
                        </div>
                    </div>
                </div>
                <form>
                    <div class="mb-4">
                        <label class="block text-sm font-bold text-slate-300 mb-2">شماره تماس</label>
                        <input type="tel" required 
                            class="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-brand-500">
                    </div>
                </form>
            </div>
        `, {
            footer: `
                <button onclick="modalManager.close('lead-${l.title}')" class="btn-secondary">انصراف</button>
                <button onclick="purchaseLead('${l.title}')" class="btn-primary">تأیید خرید</button>
            `
        });

        // محاسبه قیمت کل
        const modal = document.getElementById(`modal-lead-${l.title}`);
        if (modal) {
            const quantityInput = modal.querySelector('input[type="number"]');
            const totalPriceEl = modal.querySelector(`#total-price-${l.title}`);
            
            if (quantityInput && totalPriceEl) {
                quantityInput.addEventListener('input', (e) => {
                    const quantity = parseInt(e.target.value) || 1;
                    const total = l.price * quantity;
                    totalPriceEl.textContent = total.toLocaleString() + ' تومان';
                });
            }
        }
    });

    // Event listener برای دکمه افزودن لید
    document.addEventListener('click', (e) => {
        const btn = e.target.closest(`[data-modal^="lead-"]`);
        if (btn) {
            e.preventDefault();
            const modalId = btn.getAttribute('data-modal');
            modalManager.open(modalId);
        }
    });

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

/**
 * خرید لید
 */
function purchaseLead(leadTitle) {
    alert(`خرید لید "${leadTitle}" با موفقیت ثبت شد! به زودی با شما تماس خواهیم گرفت.`);
    modalManager.close(`lead-${leadTitle}`);
}

/**
 * راه‌اندازی اعداد شناور
 */
function initFloatingNumbers() {
    const numbersContainer = document.getElementById('floating-numbers-container');
    if (!numbersContainer) return;

    const otherPrefixes = ['0935', '0936', '0933', '0902', '0919', '0912'];
    
    for (let i = 0; i < 45; i++) {
        const el = document.createElement('div');
        const isNear = Math.random() > 0.70;
        el.className = `floating-number ${isNear ? 'near' : 'far'}`;
        
        let phoneNumber = '';
        if (isNear) {
            const rest = Math.floor(1000000 + Math.random() * 9000000);
            phoneNumber = '0912' + rest;
        } else {
            const prefix = otherPrefixes[Math.floor(Math.random() * otherPrefixes.length)];
            const rest = Math.floor(1000000 + Math.random() * 9000000);
            phoneNumber = prefix + rest;
        }
        
        el.innerText = phoneNumber;
        el.style.left = Math.floor(Math.random() * 100) + '%';
        
        const duration = isNear ? (12 + Math.random() * 8) : (20 + Math.random() * 20);
        el.style.animationDuration = `${duration}s`;
        el.style.animationDelay = `-${Math.random() * duration}s`;
        
        if (isNear) {
            el.style.setProperty('--scale', (1.0 + Math.random() * 0.5).toFixed(2));
            el.style.setProperty('--opacity', (0.2 + Math.random() * 0.2).toFixed(2));
        } else {
            el.style.setProperty('--scale', (0.6 + Math.random() * 0.4).toFixed(2));
            el.style.setProperty('--opacity', (0.1 + Math.random() * 0.15).toFixed(2));
        }
        
        numbersContainer.appendChild(el);
    }
}

